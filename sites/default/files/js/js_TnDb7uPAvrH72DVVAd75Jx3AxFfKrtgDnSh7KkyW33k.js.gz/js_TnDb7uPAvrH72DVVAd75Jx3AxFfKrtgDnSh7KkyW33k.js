Drupal.locale={"pluralFormula":function($n){return Number($n!=1)},"strings":{"":{"An AJAX HTTP error occurred.":"Hubo un error HTTP AJAX.","HTTP Result Code: !status":"C\u00f3digo de Resultado HTTP: !status","An AJAX HTTP request terminated abnormally.":"Una solicitud HTTP de AJAX termin\u00f3 de manera anormal.","Debugging information follows.":"A continuaci\u00f3n se detalla la informaci\u00f3n de depuraci\u00f3n.","Path: !uri":"Ruta: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText: !responseText",
"ReadyState: !readyState":"ReadyState: !readyState","All":"Todo(s)","New":"Nuevo","Recent":"Reciente","Select all rows in this table":"Seleccionar todas las filas de esta tabla","Deselect all rows in this table":"Quitar la selecci\u00f3n a todas las filas de esta tabla","Hide":"Ocultar","Show":"Mostrar","Configure":"Configurar","(active tab)":"(solapa activa)","Not restricted":"Sin restricci\u00f3n","All pages with exceptions":"Todas las p\u00e1ginas con excepciones","Restricted to certain pages":"Restringido a algunas p\u00e1ginas",
"Excepted: @roles":"Exceptuando: @roles","Not customizable":"No personalizable","On by default with opt out":"Activado por defecto con opci\u00f3n de desactivar","Off by default with opt in":"Desactivado por defecto con elecci\u00f3n de activar","Mailto links":"Enlaces de Correo electr\u00f3nico","Downloads":"Descargas","Not tracked":"No monitorizado","@items enabled":"@items activado","AdSense ads":"Anuncios de AdSense","Display features":"Caracter\u00edsticas de la presentaci\u00f3n","A single domain":"Un \u00fanico dominio",
"One domain with multiple subdomains":"Un dominio con m\u00faltiples subdominios","Multiple top-level domains":"M\u00faltiples dominios de nivel superior","Anonymize IP":"Anonimizar IP","Universal web tracking opt-out":"Desactivaci\u00f3n universal de monitorizaci\u00f3n web","No privacy":"Sin privacidad","Loading token browser...":"Cargando navegador de comodines...","Available tokens":"Comodines disponibles","Insert this token into your form":"Inserte este comod\u00edn en su formulario","Re-order rows by numerical weight instead of dragging.":"Reordenar las filas por peso num\u00e9rico en lugar de arrastrar.",
"Show row weights":"Mostrar pesos de la fila","Hide row weights":"Ocultar pesos de la fila","Drag to re-order":"Arrastre para reordenar","Changes made in this table will not be saved until the form is submitted.":"Los cambios realizados en esta tabla no se guardar\u00e1n hasta que se env\u00ede el formulario","Please wait...":"Espere, por favor...","Edit":"Editar","Also allow !name role to !permission?":"\u00bfTambi\u00e9n permitir al rol !name el permiso !permission?","Add":"Agregar","Done":"Hecho",
"Now Editing: ":"Ahora edici\u00f3n: ","Desired block weight exceeds available weight options, please check weights for blocks before saving":"Peso del bloque deseado excede opciones de peso disponible, por favor revise pesos para los bloques antes de guardar","Disabled":"Desactivado","Enabled":"Activado","Upload":"Subir al servidor","This field is required.":"Este campo es obligatorio.","Navigation":"Navegaci\u00f3n","Not published":"No publicado","Only files with the following extensions are allowed: %files-allowed.":"S\u00f3lo se permiten archivos con las siguientes extensiones: %files-allowed.",
"By @name on @date":"Por @name en @date","By @name":"Por @name","Not in menu":"No est\u00e1 en un men\u00fa","Alias: @alias":"Alias: @alias","No alias":"Sin alias","New revision":"Nueva revisi\u00f3n","The changes to these blocks will not be saved until the <em>Save blocks</em> button is clicked.":"Los cambios sobre estos bloques no se guardar\u00e1n hasta que no pulse el bot\u00f3n <em>Guardar bloques</em>.","This permission is inherited from the authenticated user role.":"Este permiso se hereda del rol de usuario registrado.",
"No revision":"Sin revisi\u00f3n","@number comments per page":"@number comentarios por p\u00e1gina","Requires a title":"Necesita un t\u00edtulo","The block cannot be placed in this region.":"El bloque no se puede colocar en esta regi\u00f3n.","Customize dashboard":"Personalizar panel de control","Hide summary":"Ocultar resumen","Edit summary":"Editar resumen","Don't display post information":"No mostrar informaci\u00f3n del env\u00edo","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"El archivo seleccionado %filename no puede ser subido. Solo se permiten archivos con las siguientes extensiones: %extensions.",
"Autocomplete popup":"Ventana emergente con autocompletado","Searching for matches...":"Buscando coincidencias","Click update to save the configuration":"Pulse actualizar para guardar la configuraci\u00f3n","Close":"Cerrar","Log messages":"Registrar mensajes","Please select a file.":"Seleccione un documento, por favor.","You are not allowed to operate on more than %num files.":"No tiene permiso para actuar sobre m\u00e1s de %num documentos.","Please specify dimensions within the allowed range that is from 1x1 to @dimensions.":"Especifique unas dimensiones dentro de las permitidas, por favor. Eso va desde 1 \u00d7 1 a @dimensions.",
"%filename is not an image.":"%filename no es una imagen.","Do you want to refresh the current directory?":"\u00bfQuiere actualizar la vista de este directorio?","Delete selected files?":"\u00bfBorrar los documentos seleccionados?","Please select a thumbnail.":"Seleccione una minatura, por favor.","You must select at least %num files.":"Debe seleccionar al menos %num documentos.","You can not perform this operation.":"No puede realizar esta operaci\u00f3n.","Insert file":"Insertar archivo","Change view":"Cambiar vista",
"Show description":"Mostrar descripci\u00f3n","Hide description":"Esconder descripci\u00f3n","Remove this pane?":"\u00bfEliminar este panel?","Automatic alias":"Alias autom\u00e1tico","Remove group":"Eliminar grupo","Apply (all displays)":"Aplicar (todas las presentaciones)","Apply (this display)":"Aplicar (esta presentaci\u00f3n)","Revert to default":"Volver al valor inicial","required":"necesario","Inclusion: @value":"Inclusi\u00f3n: @value","Priority: @value":"Prioridad: @value"}}};;
(function(t,e,i){function n(i,n,o){var r=e.createElement(i);return n&&(r.id=Z+n),o&&(r.style.cssText=o),t(r)}function o(){return i.innerHeight?i.innerHeight:t(i).height()}function r(e,i){i!==Object(i)&&(i={}),this.cache={},this.el=e,this.value=function(e){var n;return void 0===this.cache[e]&&(n=t(this.el).attr("data-cbox-"+e),void 0!==n?this.cache[e]=n:void 0!==i[e]?this.cache[e]=i[e]:void 0!==X[e]&&(this.cache[e]=X[e])),this.cache[e]},this.get=function(e){var i=this.value(e);return t.isFunction(i)?
i.call(this.el,this):i}}function h(t){var e=W.length,i=(A+t)%e;return 0>i?e+i:i}function a(t,e){return Math.round((/%/.test(t)?("x"===e?E.width():o())/100:1)*parseInt(t,10))}function s(t,e){return t.get("photo")||t.get("photoRegex").test(e)}function l(t,e){return t.get("retinaUrl")&&i.devicePixelRatio>1?e.replace(t.get("photoRegex"),t.get("retinaSuffix")):e}function d(t){"contains"in y[0]&&!y[0].contains(t.target)&&t.target!==v[0]&&(t.stopPropagation(),y.focus())}function c(t){c.str!==t&&(y.add(v).removeClass(c.str).addClass(t),
c.str=t)}function g(e){A=0,e&&e!==!1&&"nofollow"!==e?(W=t("."+te).filter(function(){var i=t.data(this,Y),n=new r(this,i);return n.get("rel")===e}),A=W.index(_.el),-1===A&&(W=W.add(_.el),A=W.length-1)):W=t(_.el)}function u(i){t(e).trigger(i),ae.triggerHandler(i)}function f(i){var o;if(!G){if(o=t(i).data(Y),_=new r(i,o),g(_.get("rel")),!$){$=q=!0,c(_.get("className")),y.css({visibility:"hidden",display:"block",opacity:""}),I=n(se,"LoadedContent","width:0; height:0; overflow:hidden; visibility:hidden"),
b.css({width:"",height:""}).append(I),j=T.height()+k.height()+b.outerHeight(!0)-b.height(),D=C.width()+H.width()+b.outerWidth(!0)-b.width(),N=I.outerHeight(!0),z=I.outerWidth(!0);var h=a(_.get("initialWidth"),"x"),s=a(_.get("initialHeight"),"y"),l=_.get("maxWidth"),f=_.get("maxHeight");_.w=(l!==!1?Math.min(h,a(l,"x")):h)-z-D,_.h=(f!==!1?Math.min(s,a(f,"y")):s)-N-j,I.css({width:"",height:_.h}),J.position(),u(ee),_.get("onOpen"),O.add(S).hide(),y.focus(),_.get("trapFocus")&&e.addEventListener&&(e.addEventListener("focus",
d,!0),ae.one(re,function(){e.removeEventListener("focus",d,!0)})),_.get("returnFocus")&&ae.one(re,function(){t(_.el).focus()})}var p=parseFloat(_.get("opacity"));v.css({opacity:p===p?p:"",cursor:_.get("overlayClose")?"pointer":"",visibility:"visible"}).show(),_.get("closeButton")?B.html(_.get("close")).appendTo(b):B.appendTo("<div/>"),w()}}function p(){y||(V=!1,E=t(i),y=n(se).attr({id:Y,"class":t.support.opacity===!1?Z+"IE":"",role:"dialog",tabindex:"-1"}).hide(),v=n(se,"Overlay").hide(),M=t([n(se,
"LoadingOverlay")[0],n(se,"LoadingGraphic")[0]]),x=n(se,"Wrapper"),b=n(se,"Content").append(S=n(se,"Title"),F=n(se,"Current"),P=t('<button type="button"/>').attr({id:Z+"Previous"}),K=t('<button type="button"/>').attr({id:Z+"Next"}),R=n("button","Slideshow"),M),B=t('<button type="button"/>').attr({id:Z+"Close"}),x.append(n(se).append(n(se,"TopLeft"),T=n(se,"TopCenter"),n(se,"TopRight")),n(se,!1,"clear:left").append(C=n(se,"MiddleLeft"),b,H=n(se,"MiddleRight")),n(se,!1,"clear:left").append(n(se,"BottomLeft"),
k=n(se,"BottomCenter"),n(se,"BottomRight"))).find("div div").css({"float":"left"}),L=n(se,!1,"position:absolute; width:9999px; visibility:hidden; display:none; max-width:none;"),O=K.add(P).add(F).add(R)),e.body&&!y.parent().length&&t(e.body).append(v,y.append(x,L))}function m(){function i(t){t.which>1||t.shiftKey||t.altKey||t.metaKey||t.ctrlKey||(t.preventDefault(),f(this))}return y?(V||(V=!0,K.click(function(){J.next()}),P.click(function(){J.prev()}),B.click(function(){J.close()}),v.click(function(){_.get("overlayClose")&&
J.close()}),t(e).bind("keydown."+Z,function(t){var e=t.keyCode;$&&_.get("escKey")&&27===e&&(t.preventDefault(),J.close()),$&&_.get("arrowKey")&&W[1]&&!t.altKey&&(37===e?(t.preventDefault(),P.click()):39===e&&(t.preventDefault(),K.click()))}),t.isFunction(t.fn.on)?t(e).on("click."+Z,"."+te,i):t("."+te).live("click."+Z,i)),!0):!1}function w(){var e,o,r,h=J.prep,d=++le;if(q=!0,U=!1,u(he),u(ie),_.get("onLoad"),_.h=_.get("height")?a(_.get("height"),"y")-N-j:_.get("innerHeight")&&a(_.get("innerHeight"),
"y"),_.w=_.get("width")?a(_.get("width"),"x")-z-D:_.get("innerWidth")&&a(_.get("innerWidth"),"x"),_.mw=_.w,_.mh=_.h,_.get("maxWidth")&&(_.mw=a(_.get("maxWidth"),"x")-z-D,_.mw=_.w&&_.w<_.mw?_.w:_.mw),_.get("maxHeight")&&(_.mh=a(_.get("maxHeight"),"y")-N-j,_.mh=_.h&&_.h<_.mh?_.h:_.mh),e=_.get("href"),Q=setTimeout(function(){M.show()},100),_.get("inline")){var c=t(e);r=t("<div>").hide().insertBefore(c),ae.one(he,function(){r.replaceWith(c)}),h(c)}else _.get("iframe")?h(" "):_.get("html")?h(_.get("html")):
s(_,e)?(e=l(_,e),U=_.get("createImg"),t(U).addClass(Z+"Photo").bind("error",function(){h(n(se,"Error").html(_.get("imgError")))}).one("load",function(){d===le&&setTimeout(function(){var t;_.get("retinaImage")&&i.devicePixelRatio>1&&(U.height=U.height/i.devicePixelRatio,U.width=U.width/i.devicePixelRatio),_.get("scalePhotos")&&(o=function(){U.height-=U.height*t,U.width-=U.width*t},_.mw&&U.width>_.mw&&(t=(U.width-_.mw)/U.width,o()),_.mh&&U.height>_.mh&&(t=(U.height-_.mh)/U.height,o())),_.h&&(U.style.marginTop=
Math.max(_.mh-U.height,0)/2+"px"),W[1]&&(_.get("loop")||W[A+1])&&(U.style.cursor="pointer",U.onclick=function(){J.next()}),U.style.width=U.width+"px",U.style.height=U.height+"px",h(U)},1)}),U.src=e):e&&L.load(e,_.get("data"),function(e,i){d===le&&h("error"===i?n(se,"Error").html(_.get("xhrError")):t(this).contents())})}var v,y,x,b,T,C,H,k,W,E,I,L,M,S,F,R,K,P,B,O,_,j,D,N,z,A,U,$,q,G,Q,J,V,X={html:!1,photo:!1,iframe:!1,inline:!1,transition:"elastic",speed:300,fadeOut:300,width:!1,initialWidth:"600",
innerWidth:!1,maxWidth:!1,height:!1,initialHeight:"450",innerHeight:!1,maxHeight:!1,scalePhotos:!0,scrolling:!0,opacity:.9,preloading:!0,className:!1,overlayClose:!0,escKey:!0,arrowKey:!0,top:!1,bottom:!1,left:!1,right:!1,fixed:!1,data:void 0,closeButton:!0,fastIframe:!0,open:!1,reposition:!0,loop:!0,slideshow:!1,slideshowAuto:!0,slideshowSpeed:2500,slideshowStart:"start slideshow",slideshowStop:"stop slideshow",photoRegex:/\.(gif|png|jp(e|g|eg)|bmp|ico|webp|jxr|svg)((#|\?).*)?$/i,retinaImage:!1,
retinaUrl:!1,retinaSuffix:"@2x.$1",current:"image {current} of {total}",previous:"previous",next:"next",close:"close",xhrError:"This content failed to load.",imgError:"This image failed to load.",returnFocus:!0,trapFocus:!0,onOpen:!1,onLoad:!1,onComplete:!1,onCleanup:!1,onClosed:!1,rel:function(){return this.rel},href:function(){return t(this).attr("href")},title:function(){return this.title},createImg:function(){var e=new Image,i=t(this).data("cbox-img-attrs");return"object"==typeof i&&t.each(i,
function(t,i){e[t]=i}),e},createIframe:function(){var i=e.createElement("iframe"),n=t(this).data("cbox-iframe-attrs");return"object"==typeof n&&t.each(n,function(t,e){i[t]=e}),"frameBorder"in i&&(i.frameBorder=0),"allowTransparency"in i&&(i.allowTransparency="true"),i.name=(new Date).getTime(),i.allowFullScreen=!0,i}},Y="colorbox",Z="cbox",te=Z+"Element",ee=Z+"_open",ie=Z+"_load",ne=Z+"_complete",oe=Z+"_cleanup",re=Z+"_closed",he=Z+"_purge",ae=t("<a/>"),se="div",le=0,de={},ce=function(){function t(){clearTimeout(h)}
function e(){(_.get("loop")||W[A+1])&&(t(),h=setTimeout(J.next,_.get("slideshowSpeed")))}function i(){R.html(_.get("slideshowStop")).unbind(s).one(s,n),ae.bind(ne,e).bind(ie,t),y.removeClass(a+"off").addClass(a+"on")}function n(){t(),ae.unbind(ne,e).unbind(ie,t),R.html(_.get("slideshowStart")).unbind(s).one(s,function(){J.next(),i()}),y.removeClass(a+"on").addClass(a+"off")}function o(){r=!1,R.hide(),t(),ae.unbind(ne,e).unbind(ie,t),y.removeClass(a+"off "+a+"on")}var r,h,a=Z+"Slideshow_",s="click."+
Z;return function(){r?_.get("slideshow")||(ae.unbind(oe,o),o()):_.get("slideshow")&&W[1]&&(r=!0,ae.one(oe,o),_.get("slideshowAuto")?i():n(),R.show())}}();t[Y]||(t(p),J=t.fn[Y]=t[Y]=function(e,i){var n,o=this;return e=e||{},t.isFunction(o)&&(o=t("<a/>"),e.open=!0),o[0]?(p(),m()&&(i&&(e.onComplete=i),o.each(function(){var i=t.data(this,Y)||{};t.data(this,Y,t.extend(i,e))}).addClass(te),n=new r(o[0],e),n.get("open")&&f(o[0])),o):o},J.position=function(e,i){function n(){T[0].style.width=k[0].style.width=
b[0].style.width=parseInt(y[0].style.width,10)-D+"px",b[0].style.height=C[0].style.height=H[0].style.height=parseInt(y[0].style.height,10)-j+"px"}var r,h,s,l=0,d=0,c=y.offset();if(E.unbind("resize."+Z),y.css({top:-9E4,left:-9E4}),h=E.scrollTop(),s=E.scrollLeft(),_.get("fixed")?(c.top-=h,c.left-=s,y.css({position:"fixed"})):(l=h,d=s,y.css({position:"absolute"})),d+=_.get("right")!==!1?Math.max(E.width()-_.w-z-D-a(_.get("right"),"x"),0):_.get("left")!==!1?a(_.get("left"),"x"):Math.round(Math.max(E.width()-
_.w-z-D,0)/2),l+=_.get("bottom")!==!1?Math.max(o()-_.h-N-j-a(_.get("bottom"),"y"),0):_.get("top")!==!1?a(_.get("top"),"y"):Math.round(Math.max(o()-_.h-N-j,0)/2),y.css({top:c.top,left:c.left,visibility:"visible"}),x[0].style.width=x[0].style.height="9999px",r={width:_.w+z+D,height:_.h+N+j,top:l,left:d},e){var g=0;t.each(r,function(t){return r[t]!==de[t]?(g=e,void 0):void 0}),e=g}de=r,e||y.css(r),y.dequeue().animate(r,{duration:e||0,complete:function(){n(),q=!1,x[0].style.width=_.w+z+D+"px",x[0].style.height=
_.h+N+j+"px",_.get("reposition")&&setTimeout(function(){E.bind("resize."+Z,J.position)},1),t.isFunction(i)&&i()},step:n})},J.resize=function(t){var e;$&&(t=t||{},t.width&&(_.w=a(t.width,"x")-z-D),t.innerWidth&&(_.w=a(t.innerWidth,"x")),I.css({width:_.w}),t.height&&(_.h=a(t.height,"y")-N-j),t.innerHeight&&(_.h=a(t.innerHeight,"y")),t.innerHeight||t.height||(e=I.scrollTop(),I.css({height:"auto"}),_.h=I.height()),I.css({height:_.h}),e&&I.scrollTop(e),J.position("none"===_.get("transition")?0:_.get("speed")))},
J.prep=function(i){function o(){return _.w=_.w||I.width(),_.w=_.mw&&_.mw<_.w?_.mw:_.w,_.w}function a(){return _.h=_.h||I.height(),_.h=_.mh&&_.mh<_.h?_.mh:_.h,_.h}if($){var d,g="none"===_.get("transition")?0:_.get("speed");I.remove(),I=n(se,"LoadedContent").append(i),I.hide().appendTo(L.show()).css({width:o(),overflow:_.get("scrolling")?"auto":"hidden"}).css({height:a()}).prependTo(b),L.hide(),t(U).css({"float":"none"}),c(_.get("className")),d=function(){function i(){t.support.opacity===!1&&y[0].style.removeAttribute("filter")}
var n,o,a=W.length;$&&(o=function(){clearTimeout(Q),M.hide(),u(ne),_.get("onComplete")},S.html(_.get("title")).show(),I.show(),a>1?("string"==typeof _.get("current")&&F.html(_.get("current").replace("{current}",A+1).replace("{total}",a)).show(),K[_.get("loop")||a-1>A?"show":"hide"]().html(_.get("next")),P[_.get("loop")||A?"show":"hide"]().html(_.get("previous")),ce(),_.get("preloading")&&t.each([h(-1),h(1)],function(){var i,n=W[this],o=new r(n,t.data(n,Y)),h=o.get("href");h&&s(o,h)&&(h=l(o,h),i=e.createElement("img"),
i.src=h)})):O.hide(),_.get("iframe")?(n=_.get("createIframe"),_.get("scrolling")||(n.scrolling="no"),t(n).attr({src:_.get("href"),"class":Z+"Iframe"}).one("load",o).appendTo(I),ae.one(he,function(){n.src="//about:blank"}),_.get("fastIframe")&&t(n).trigger("load")):o(),"fade"===_.get("transition")?y.fadeTo(g,1,i):i())},"fade"===_.get("transition")?y.fadeTo(g,0,function(){J.position(0,d)}):J.position(g,d)}},J.next=function(){!q&&W[1]&&(_.get("loop")||W[A+1])&&(A=h(1),f(W[A]))},J.prev=function(){!q&&
W[1]&&(_.get("loop")||A)&&(A=h(-1),f(W[A]))},J.close=function(){$&&!G&&(G=!0,$=!1,u(oe),_.get("onCleanup"),E.unbind("."+Z),v.fadeTo(_.get("fadeOut")||0,0),y.stop().fadeTo(_.get("fadeOut")||0,0,function(){y.hide(),v.hide(),u(he),I.remove(),setTimeout(function(){G=!1,u(re),_.get("onClosed")},1)}))},J.remove=function(){y&&(y.stop(),t[Y].close(),y.stop(!1,!0).remove(),v.remove(),G=!1,y=null,t("."+te).removeData(Y).removeClass(te),t(e).unbind("click."+Z).unbind("keydown."+Z))},J.element=function(){return t(_.el)},
J.settings=X)})(jQuery,document,window);;
(function($){Drupal.behaviors.initColorbox={attach:function(context,settings){if(!$.isFunction($.colorbox)||typeof settings.colorbox==="undefined")return;if(settings.colorbox.mobiledetect&&window.matchMedia){var mq=window.matchMedia("(max-device-width: "+settings.colorbox.mobiledevicewidth+")");if(mq.matches)return}$(".colorbox",context).once("init-colorbox").colorbox(settings.colorbox);$(context).bind("cbox_complete",function(){Drupal.attachBehaviors("#cboxLoadedContent")})}}})(jQuery);;
(function($,window,i){$.fn.tinyNav=function(options){var settings=$.extend({"active":"selected","header":false,"indent":"--","depth_count":3},options);return this.each(function(){i++;var $nav=$(this),namespace="tinynav",namespace_i=namespace+i,l_namespace_i=".l_"+namespace_i,$select=$("<select/>").addClass(namespace+" "+namespace_i);if($nav.is("ul,ol")){if(settings.header)$select.append($('<option value="-null-"/>').text(Drupal.t("Navigation")));var options="";$nav.addClass("l_"+namespace_i).find("a").each(function(){var indent=
"";var parent_count=$(this).parents("ul,ol").length;for(var i=1;i<parent_count;i++)indent+=settings.indent;if(indent!="")indent+=" ";if(parent_count<settings.depth_count)options+='<option value="'+$(this).attr("href")+'">'+indent+$(this).text()+"</option>"});$select.append(options);$select.find(":eq("+(settings.header+$(l_namespace_i+" li").index($(l_namespace_i+" ."+settings.active))+")")).attr("selected",true);$select.change(function(){if($(this).val()!="-null-")window.location.href=$(this).val()});
$(l_namespace_i).after($select)}})}})(jQuery,this,0);;
(function($){Drupal.behaviors.tinynav={attach:function(context,settings){settings.tinynav=settings.tinynav||{selector:"#zone-menu .region-menu ul.menu",media_query:"all and (max-width:780px)",header:false,active:"active-trail"};$(settings.tinynav.selector,context).addClass("tinyjs");var tinyNavSettings={header:settings.tinynav.header};if(settings.tinynav.active)tinyNavSettings.active=settings.tinynav.active;$(".tinyjs",context).tinyNav(tinyNavSettings);$("select.tinynav",context).wrap('<div class="tinynav-wrapper"/>')},
weight:99}})(jQuery);;
(function($){Drupal.behaviors.devel={attach:function(context,settings){$(".krumo-footnote .krumo-call").once().before('<img style="vertical-align: middle;" title="Click to expand. Double-click to show path." src="'+settings.basePath+'misc/help.png"/>');var krumo_name=[];var krumo_type=[];function krumo_traverse(el){krumo_name.push($(el).html());krumo_type.push($(el).siblings("em").html().match(/\w*/)[0]);if($(el).closest(".krumo-nest").length>0)krumo_traverse($(el).closest(".krumo-nest").prev().find(".krumo-name"))}
$(".krumo-child > div:first-child",context).dblclick(function(e){if($(this).find("> .krumo-php-path").length>0)$(this).find("> .krumo-php-path").remove();else{krumo_traverse($(this).find("> a.krumo-name"));var krumo_path_string="";for(var i=krumo_name.length-1;i>=0;--i){if(krumo_name.length-1==i)krumo_path_string+="$"+krumo_name[i];if(typeof krumo_name[i-1]!=="undefined"){if(krumo_type[i]=="Array"){krumo_path_string+="[";if(!/^\d*$/.test(krumo_name[i-1]))krumo_path_string+="'";krumo_path_string+=
krumo_name[i-1];if(!/^\d*$/.test(krumo_name[i-1]))krumo_path_string+="'";krumo_path_string+="]"}if(krumo_type[i]=="Object")krumo_path_string+="->"+krumo_name[i-1]}}$(this).append('<div class="krumo-php-path" style="font-family: Courier, monospace; font-weight: bold;">'+krumo_path_string+"</div>");krumo_name=[];krumo_type=[]}})}}})(jQuery);;
(function($){Drupal.behaviors.custom_search={attach:function(context){if(!Drupal.settings.custom_search.solr)$("form.search-form",context).submit(function(){var $this=$(this);var box=$this.find("input.custom-search-box");if(box.val()!=undefined&&box.val()==""){$this.find("input.custom-search-box").addClass("error");return false}if($this.find("#edit-keys").parents("div.element-invisible").attr("class")=="element-invisible"){$this.find("#edit-keys").val($this.find("#edit-or").val());$this.find("#edit-or").val("")}return true});
$("form.search-form").attr("target",Drupal.settings.custom_search.form_target);$("form.search-form input.custom-search-box",context).bind("click focus",function(e){var $parentForm=$(this).parents("form");var popup=$parentForm.find("fieldset.custom_search-popup");if(popup.find("input,select").length&&!popup.hasClass("opened"))popup.fadeIn().addClass("opened");e.stopPropagation()});$(document).bind("click focus",function(){$("fieldset.custom_search-popup").hide().removeClass("opened")});$(".custom-search-selector input:checkbox",
context).each(function(){var el=$(this);if(el.val()=="c-all")el.change(function(){$(this).parents(".custom-search-selector").find("input:checkbox[value!=c-all]").attr("checked",false)});else if(el.val().substr(0,2)=="c-")el.change(function(){$(".custom-search-selector input:checkbox").each(function(){if($(this).val().substr(0,2)=="o-")$(this).attr("checked",false)});$(this).parents(".custom-search-selector").find("input:checkbox[value=c-all]").attr("checked",false)});else el.change(function(){$(this).parents(".custom-search-selector").find("input:checkbox[value!="+
el.val()+"]").attr("checked",false)})});var popup=$("fieldset.custom_search-popup:not(.custom_search-processed)",context).addClass("custom_search-processed");popup.click(function(e){e.stopPropagation()});popup.append('<a class="custom_search-popup-close" href="#">'+Drupal.t("Close")+"</a>");$("a.custom_search-popup-close").click(function(e){$("fieldset.custom_search-popup.opened").hide().removeClass("opened");e.preventDefault()})}}})(jQuery);;
(function($){Drupal.progressBar=function(id,updateCallback,method,errorCallback){var pb=this;this.id=id;this.method=method||"GET";this.updateCallback=updateCallback;this.errorCallback=errorCallback;this.element=$('<div class="progress" aria-live="polite"></div>').attr("id",id);this.element.html('<div class="bar"><div class="filled"></div></div>'+'<div class="percentage"></div>'+'<div class="message">&nbsp;</div>')};Drupal.progressBar.prototype.setProgress=function(percentage,message){if(percentage>=
0&&percentage<=100){$("div.filled",this.element).css("width",percentage+"%");$("div.percentage",this.element).html(percentage+"%")}$("div.message",this.element).html(message);if(this.updateCallback)this.updateCallback(percentage,message,this)};Drupal.progressBar.prototype.startMonitoring=function(uri,delay){this.delay=delay;this.uri=uri;this.sendPing()};Drupal.progressBar.prototype.stopMonitoring=function(){clearTimeout(this.timer);this.uri=null};Drupal.progressBar.prototype.sendPing=function(){if(this.timer)clearTimeout(this.timer);
if(this.uri){var pb=this;$.ajax({type:this.method,url:this.uri,data:"",dataType:"json",success:function(progress){if(progress.status==0){pb.displayError(progress.data);return}pb.setProgress(progress.percentage,progress.message);pb.timer=setTimeout(function(){pb.sendPing()},pb.delay)},error:function(xmlhttp){pb.displayError(Drupal.ajaxError(xmlhttp,pb.uri))}})}};Drupal.progressBar.prototype.displayError=function(string){var error=$('<div class="messages error"></div>').html(string);$(this.element).before(error).hide();
if(this.errorCallback)this.errorCallback(this)}})(jQuery);;
var urlactual = document.URL.replace( /#.*/, "");
urlactual = urlactual.replace( /\?.*/, "");

(function ($) {

	<!--Google Analytics Evento Scroll-->
	var times = 0;
	//location.hash = '';
	$(window).scroll(function(){
		var bottom = $(window).height() + $(window).scrollTop();
		var height = $(document).height();
		var percentage = Math.round(100*bottom/height);
		if(percentage > 50 && times==0){
			times=times + 1;
			ga('send', 'event', 'Scroll', '50%', urlactual);
		}
	});
	
	<!--Google Analytics Evento Segundos-->
	setTimeout(function(){ga('send', 'event', 'T>30s', 'Tiempo mayor a 30 segundos', urlactual);},30000);

Drupal.googleanalytics = {};

$(document).ready(function() {

  // Attach mousedown, keyup, touchstart events to document only and catch
  // clicks on all elements.
  $(document.body).bind("mousedown keyup touchstart", function(event) {

    // Catch the closest surrounding link of a clicked element.
    $(event.target).closest("a,area").each(function() {

      // Is the clicked URL internal?
      if (Drupal.googleanalytics.isInternal(this.href)) {
        // Skip 'click' tracking, if custom tracking events are bound.
        if ($(this).is('.colorbox')) {
          // Do nothing here. The custom event will handle all tracking.
          //console.info("Click on .colorbox item has been detected.");
        }
        // Is download tracking activated and the file extension configured for download tracking?
        else if (Drupal.settings.googleanalytics.trackDownload && Drupal.googleanalytics.isDownload(this.href)) {
          // Download link clicked.
          ga("send", "event", "Descargas", Drupal.googleanalytics.getDownloadExtension(this.href).toUpperCase(), Drupal.googleanalytics.getPageUrl(this.href));
        }
        else if (Drupal.googleanalytics.isInternalSpecial(this.href)) {
          // Keep the internal URL for Google Analytics website overlay intact.
          ga("send", "pageview", { "page": Drupal.googleanalytics.getPageUrl(this.href) });
        }
      }
      else {
        if (Drupal.settings.googleanalytics.trackMailto && $(this).is("a[href^='mailto:'],area[href^='mailto:']")) {
          // Mailto link clicked.
          ga("send", "event", "Correos", "Click", this.href.substring(7));
        }
        else if (Drupal.settings.googleanalytics.trackOutbound && this.href.match(/^\w+:\/\//i)) {
          if (Drupal.settings.googleanalytics.trackDomainMode != 2 || (Drupal.settings.googleanalytics.trackDomainMode == 2 && !Drupal.googleanalytics.isCrossDomain(this.hostname, Drupal.settings.googleanalytics.trackCrossDomains))) {
            // External link clicked / No top-level cross domain clicked.
            ga("send", "event", "Enlaces salientes", "Click", this.href);
          }
        }
      }
    });
  });

  // Track hash changes as unique pageviews, if this option has been enabled.
  if (Drupal.settings.googleanalytics.trackUrlFragments) {
    window.onhashchange = function() {
      ga('send', 'pageview', location.pathname + location.search + location.hash);
    }
  }

  // Colorbox: This event triggers when the transition has completed and the
  // newly loaded content has been revealed.
  $(document).bind("cbox_complete", function () {
    var href = $.colorbox.element().attr("href");
    if (href) {
      ga("send", "pageview", { "page": Drupal.googleanalytics.getPageUrl(href) });
    }
  });

});

/**
 * Check whether the hostname is part of the cross domains or not.
 *
 * @param string hostname
 *   The hostname of the clicked URL.
 * @param array crossDomains
 *   All cross domain hostnames as JS array.
 *
 * @return boolean
 */
Drupal.googleanalytics.isCrossDomain = function (hostname, crossDomains) {
  /**
   * jQuery < 1.6.3 bug: $.inArray crushes IE6 and Chrome if second argument is
   * `null` or `undefined`, http://bugs.jquery.com/ticket/10076,
   * https://github.com/jquery/jquery/commit/a839af034db2bd934e4d4fa6758a3fed8de74174
   *
   * @todo: Remove/Refactor in D8
   */
  if (!crossDomains) {
    return false;
  }
  else {
    return $.inArray(hostname, crossDomains) > -1 ? true : false;
  }
};

/**
 * Check whether this is a download URL or not.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isDownload = function (url) {
  var isDownload = new RegExp("\\.(" + Drupal.settings.googleanalytics.trackDownloadExtensions + ")([\?#].*)?$", "i");
  return isDownload.test(url);
};

/**
 * Check whether this is an absolute internal URL or not.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isInternal = function (url) {
  var isInternal = new RegExp("^(https?):\/\/" + window.location.host, "i");
  return isInternal.test(url);
};

/**
 * Check whether this is a special URL or not.
 *
 * URL types:
 *  - gotwo.module /go/* links.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isInternalSpecial = function (url) {
  var isInternalSpecial = new RegExp("(\/go\/.*)$", "i");
  return isInternalSpecial.test(url);
};

/**
 * Extract the relative internal URL from an absolute internal URL.
 *
 * Examples:
 * - http://mydomain.com/node/1 -> /node/1
 * - http://example.com/foo/bar -> http://example.com/foo/bar
 *
 * @param string url
 *   The web url to check.
 *
 * @return string
 *   Internal website URL
 */
Drupal.googleanalytics.getPageUrl = function (url) {
  var extractInternalUrl = new RegExp("^(https?):\/\/" + window.location.host, "i");
  return url.replace(extractInternalUrl, '');
};

/**
 * Extract the download file extension from the URL.
 *
 * @param string url
 *   The web url to check.
 *
 * @return string
 *   The file extension of the passed url. e.g. "zip", "txt"
 */
Drupal.googleanalytics.getDownloadExtension = function (url) {
  var extractDownloadextension = new RegExp("\\.(" + Drupal.settings.googleanalytics.trackDownloadExtensions + ")([\?#].*)?$", "i");
  var extension = extractDownloadextension.exec(url);
  return (extension === null) ? '' : extension[1];
};

})(jQuery);
;
(function($){Drupal.behaviors.webform=Drupal.behaviors.webform||{};Drupal.behaviors.webform.attach=function(context){Drupal.webform.datepicker(context);if(Drupal.settings.webform&&Drupal.settings.webform.conditionals)Drupal.webform.conditional(context)};Drupal.webform=Drupal.webform||{};Drupal.webform.datepicker=function(context){$("div.webform-datepicker").each(function(){var $webformDatepicker=$(this);var $calendar=$webformDatepicker.find("input.webform-calendar");if($calendar.length==0)return;
var startDate=$calendar[0].className.replace(/.*webform-calendar-start-(\d{4}-\d{2}-\d{2}).*/,"$1").split("-");var endDate=$calendar[0].className.replace(/.*webform-calendar-end-(\d{4}-\d{2}-\d{2}).*/,"$1").split("-");var firstDay=$calendar[0].className.replace(/.*webform-calendar-day-(\d).*/,"$1");startDate=new Date(startDate[0],startDate[1]-1,startDate[2]);endDate=new Date(endDate[0],endDate[1]-1,endDate[2]);if(startDate>endDate){var laterDate=startDate;startDate=endDate;endDate=laterDate}var startYear=
startDate.getFullYear();var endYear=endDate.getFullYear();$calendar.datepicker({dateFormat:"yy-mm-dd",yearRange:startYear+":"+endYear,firstDay:parseInt(firstDay),minDate:startDate,maxDate:endDate,onSelect:function(dateText,inst){var date=dateText.split("-");$webformDatepicker.find("select.year, input.year").val(+date[0]).trigger("change");$webformDatepicker.find("select.month").val(+date[1]).trigger("change");$webformDatepicker.find("select.day").val(+date[2]).trigger("change")},beforeShow:function(input,
inst){var year=$webformDatepicker.find("select.year, input.year").val();var month=$webformDatepicker.find("select.month").val();var day=$webformDatepicker.find("select.day").val();var today=new Date;year=year?year:today.getFullYear();month=month?month:today.getMonth()+1;day=day?day:today.getDate();year=year<startYear||year>endYear?startYear:year;$(input).val(year+"-"+month+"-"+day)}});$calendar.click(function(event){$(this).focus();event.preventDefault()})})};Drupal.webform.conditional=function(context){$.each(Drupal.settings.webform.conditionals,
function(formKey,settings){var $form=$("."+formKey+":not(.webform-conditional-processed)");$form.each(function(index,currentForm){var $currentForm=$(currentForm);$currentForm.addClass("webform-conditional-processed");$currentForm.bind("change",{"settings":settings},Drupal.webform.conditionalCheck);Drupal.webform.doConditions($form,settings)})})};Drupal.webform.conditionalCheck=function(e){var $triggerElement=$(e.target).closest(".webform-component");var $form=$triggerElement.closest("form");var triggerElementKey=
$triggerElement.attr("class").match(/webform-component--[^ ]+/)[0];var settings=e.data.settings;if(settings.sourceMap[triggerElementKey])Drupal.webform.doConditions($form,settings)};Drupal.webform.doConditions=function($form,settings){var targetLocked=[];$.each(settings.ruleGroups,function(rgid_key,rule_group){var ruleGroup=settings.ruleGroups[rgid_key];var conditionalResult=true;var conditionalResults=[];$.each(ruleGroup["rules"],function(m,rule){var elementKey=rule["source"];var element=$form.find("."+
elementKey)[0];var existingValue=settings.values[elementKey]?settings.values[elementKey]:null;conditionalResults.push(window["Drupal"]["webform"][rule.callback](element,existingValue,rule["value"]))});var filteredResults=[];for(var i=0;i<conditionalResults.length;i++)if(conditionalResults[i])filteredResults.push(conditionalResults[i]);if(ruleGroup["andor"]==="or")conditionalResult=filteredResults.length>0;else conditionalResult=filteredResults.length===conditionalResults.length;$.each(ruleGroup["actions"],
function(aid,action){var $target=$form.find("."+action["target"]);var actionResult=action["invert"]?!conditionalResult:conditionalResult;switch(action["action"]){case "show":if(actionResult!=Drupal.webform.isVisible($target)){var $targetElements=actionResult?$target.find(".webform-conditional-disabled").removeClass("webform-conditional-disabled"):$target.find(":input").addClass("webform-conditional-disabled");$targetElements.webformProp("disabled",!actionResult);$target.toggleClass("webform-conditional-hidden",
!actionResult);if(actionResult)$target.show();else{$target.hide();targetLocked[action["target"]]="hide"}if($target.is("tr"))Drupal.webform.restripeTable($target.closest("table").first())}break;case "require":var $requiredSpan=$target.find(".form-required, .form-optional").first();if(actionResult!=$requiredSpan.hasClass("form-required")){var $targetInputElements=$target.find("input:text,textarea,input[type='email'],select,input:radio,input:file");Drupal.detachBehaviors($requiredSpan);$targetInputElements.webformProp("required",
actionResult).toggleClass("required",actionResult);if(actionResult)$requiredSpan.replaceWith('<span class="form-required" title="'+Drupal.t("This field is required.")+'">*</span>');else $requiredSpan.replaceWith('<span class="form-optional"></span>');Drupal.attachBehaviors($requiredSpan)}break;case "set":var isLocked=targetLocked[action["target"]];var $texts=$target.find("input:text,textarea,input[type='email']");var $selects=$target.find("select,select option,input:radio,input:checkbox");var $markups=
$target.filter(".webform-component-markup");if(actionResult){var multiple=$.map(action["argument"].split(","),$.trim);$selects.webformVal(multiple);$texts.val([action["argument"]]);$markups.html(action["argument"])}else $markups.each(function(){var $this=$(this);var original=$this.data("webform-markup");if(original!==undefined)$this.html(original)});if(!isLocked){$selects.webformProp("disabled",actionResult);$texts.webformProp("readonly",actionResult);targetLocked[action["target"]]=actionResult?"set":
false}break}})})};Drupal.webform.stopEvent=function(){return false};Drupal.webform.conditionalOperatorStringEqual=function(element,existingValue,ruleValue){var returnValue=false;var currentValue=Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase()===ruleValue.toLowerCase()){returnValue=true;return false}});return returnValue};Drupal.webform.conditionalOperatorStringNotEqual=function(element,existingValue,ruleValue){var found=false;var currentValue=
Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase()===ruleValue.toLowerCase())found=true});return!found};Drupal.webform.conditionalOperatorStringContains=function(element,existingValue,ruleValue){var returnValue=false;var currentValue=Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase().indexOf(ruleValue.toLowerCase())>-1){returnValue=true;return false}});return returnValue};Drupal.webform.conditionalOperatorStringDoesNotContain=
function(element,existingValue,ruleValue){var found=false;var currentValue=Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase().indexOf(ruleValue.toLowerCase())>-1)found=true});return!found};Drupal.webform.conditionalOperatorStringBeginsWith=function(element,existingValue,ruleValue){var returnValue=false;var currentValue=Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase().indexOf(ruleValue.toLowerCase())===
0){returnValue=true;return false}});return returnValue};Drupal.webform.conditionalOperatorStringEndsWith=function(element,existingValue,ruleValue){var returnValue=false;var currentValue=Drupal.webform.stringValue(element,existingValue);$.each(currentValue,function(n,value){if(value.toLowerCase().lastIndexOf(ruleValue.toLowerCase())===value.length-ruleValue.length){returnValue=true;return false}});return returnValue};Drupal.webform.conditionalOperatorStringEmpty=function(element,existingValue,ruleValue){var currentValue=
Drupal.webform.stringValue(element,existingValue);var returnValue=true;$.each(currentValue,function(n,value){if(value!==""){returnValue=false;return false}});return returnValue};Drupal.webform.conditionalOperatorStringNotEmpty=function(element,existingValue,ruleValue){return!Drupal.webform.conditionalOperatorStringEmpty(element,existingValue,ruleValue)};Drupal.webform.conditionalOperatorSelectGreaterThan=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,
existingValue);return Drupal.webform.compare_select(currentValue[0],ruleValue,element)>0};Drupal.webform.conditionalOperatorSelectGreaterThanEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,existingValue);var comparison=Drupal.webform.compare_select(currentValue[0],ruleValue,element);return comparison>0||comparison===0};Drupal.webform.conditionalOperatorSelectLessThan=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,
existingValue);return Drupal.webform.compare_select(currentValue[0],ruleValue,element)<0};Drupal.webform.conditionalOperatorSelectLessThanEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,existingValue);var comparison=Drupal.webform.compare_select(currentValue[0],ruleValue,element);return comparison<0||comparison===0};Drupal.webform.conditionalOperatorNumericEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,
existingValue);var epsilon=1E-6;return currentValue[0]===""?false:Math.abs(parseFloat(currentValue[0])-parseFloat(ruleValue))<epsilon};Drupal.webform.conditionalOperatorNumericNotEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,existingValue);var epsilon=1E-6;return currentValue[0]===""?true:Math.abs(parseFloat(currentValue[0])-parseFloat(ruleValue))>=epsilon};Drupal.webform.conditionalOperatorNumericGreaterThan=function(element,existingValue,ruleValue){var currentValue=
Drupal.webform.stringValue(element,existingValue);return parseFloat(currentValue[0])>parseFloat(ruleValue)};Drupal.webform.conditionalOperatorNumericGreaterThanEqual=function(element,existingValue,ruleValue){return Drupal.webform.conditionalOperatorNumericGreaterThan(element,existingValue,ruleValue)||Drupal.webform.conditionalOperatorNumericEqual(element,existingValue,ruleValue)};Drupal.webform.conditionalOperatorNumericLessThan=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.stringValue(element,
existingValue);return parseFloat(currentValue[0])<parseFloat(ruleValue)};Drupal.webform.conditionalOperatorNumericLessThanEqual=function(element,existingValue,ruleValue){return Drupal.webform.conditionalOperatorNumericLessThan(element,existingValue,ruleValue)||Drupal.webform.conditionalOperatorNumericEqual(element,existingValue,ruleValue)};Drupal.webform.conditionalOperatorDateEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.dateValue(element,existingValue);return currentValue===
ruleValue};Drupal.webform.conditionalOperatorDateNotEqual=function(element,existingValue,ruleValue){return!Drupal.webform.conditionalOperatorDateEqual(element,existingValue,ruleValue)};Drupal.webform.conditionalOperatorDateBefore=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.dateValue(element,existingValue);return currentValue!==false&&currentValue<ruleValue};Drupal.webform.conditionalOperatorDateBeforeEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.dateValue(element,
existingValue);return currentValue!==false&&(currentValue<ruleValue||currentValue===ruleValue)};Drupal.webform.conditionalOperatorDateAfter=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.dateValue(element,existingValue);return currentValue!==false&&currentValue>ruleValue};Drupal.webform.conditionalOperatorDateAfterEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.dateValue(element,existingValue);return currentValue!==false&&(currentValue>ruleValue||
currentValue===ruleValue)};Drupal.webform.conditionalOperatorTimeEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.timeValue(element,existingValue);return currentValue===ruleValue};Drupal.webform.conditionalOperatorTimeNotEqual=function(element,existingValue,ruleValue){return!Drupal.webform.conditionalOperatorTimeEqual(element,existingValue,ruleValue)};Drupal.webform.conditionalOperatorTimeBefore=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.timeValue(element,
existingValue);return currentValue!==false&&currentValue<ruleValue};Drupal.webform.conditionalOperatorTimeBeforeEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.timeValue(element,existingValue);return currentValue!==false&&(currentValue<ruleValue||currentValue===ruleValue)};Drupal.webform.conditionalOperatorTimeAfter=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.timeValue(element,existingValue);return currentValue!==false&&currentValue>ruleValue};
Drupal.webform.conditionalOperatorTimeAfterEqual=function(element,existingValue,ruleValue){var currentValue=Drupal.webform.timeValue(element,existingValue);return currentValue!==false&&(currentValue>ruleValue||currentValue===ruleValue)};Drupal.webform.compare_select=function(a,b,element){var optionList=[];$("option,input:radio,input:checkbox",element).each(function(){optionList.push($(this).val())});var a_position=optionList.indexOf(a);var b_position=optionList.indexOf(b);return a_position<0||b_position<
0?null:a_position-b_position};Drupal.webform.isVisible=function($element){return $element.hasClass("webform-component-hidden")?!$element.find("input").first().hasClass("webform-conditional-disabled"):$element.closest(".webform-conditional-hidden").length==0};Drupal.webform.stringValue=function(element,existingValue){var value=[];if(element){var $element=$(element);if(Drupal.webform.isVisible($element)){$element.find("input[type=checkbox]:checked,input[type=radio]:checked").each(function(){value.push(this.value)});
if(!value.length){var selectValue=$element.find("select").val();if(selectValue)if($.isArray(selectValue))value=selectValue;else value.push(selectValue)}if(!value.length)$element.find("input:not([type=checkbox],[type=radio]),textarea").each(function(){value.push(this.value)})}}else switch($.type(existingValue)){case "array":value=existingValue;break;case "string":value.push(existingValue);break}return value};Drupal.webform.dateValue=function(element,existingValue){var value=false;if(element){var $element=
$(element);if(Drupal.webform.isVisible($element)){var day=$element.find("[name*=day]").val();var month=$element.find("[name*=month]").val();var year=$element.find("[name*=year]").val();if(month)month--;if(year!==""&&month!==""&&day!=="")value=Date.UTC(year,month,day)/1E3}}else{if($.type(existingValue)==="array"&&existingValue.length)existingValue=existingValue[0];if($.type(existingValue)==="string")existingValue=existingValue.split("-");if(existingValue.length===3)value=Date.UTC(existingValue[0],
existingValue[1],existingValue[2])/1E3}return value};Drupal.webform.timeValue=function(element,existingValue){var value=false;if(element){var $element=$(element);if(Drupal.webform.isVisible($element)){var hour=$element.find("[name*=hour]").val();var minute=$element.find("[name*=minute]").val();var ampm=$element.find("[name*=ampm]:checked").val();hour=hour===""?hour:parseInt(hour);minute=minute===""?minute:parseInt(minute);if(hour!==""){hour=hour<12&&ampm=="pm"?hour+12:hour;hour=hour===12&&ampm=="am"?
0:hour}if(hour!==""&&minute!=="")value=Date.UTC(1970,0,1,hour,minute)/1E3}}else{if($.type(existingValue)==="array"&&existingValue.length)existingValue=existingValue[0];if($.type(existingValue)==="string")existingValue=existingValue.split(":");if(existingValue.length>=2)value=Date.UTC(1970,0,1,existingValue[0],existingValue[1])/1E3}return value};$.fn.webformProp=$.fn.webformProp||function(name,value){if(value)return $.fn.prop?this.prop(name,true):this.attr(name,true);else return $.fn.prop?this.prop(name,
false):this.removeAttr(name)};$.fn.webformVal=function(values){this.each(function(){var $this=$(this);var value=$this.val();var on=$.inArray($this.val(),values)!=-1;if(this.nodeName=="OPTION")$this.webformProp("selected",on?value:false);else $this.val(on?[value]:false)});return this};Drupal.webform.restripeTable=function(table){$("> tbody > tr, > tr",table).filter(":visible:odd").filter(".odd").removeClass("odd").addClass("even").end().end().filter(":visible:even").filter(".even").removeClass("even").addClass("odd")}})(jQuery);;
